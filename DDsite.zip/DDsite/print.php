<!DOCTYPE html>
<html>
	
	<head>
		<meta charset="utf-8">
		<title>Jimbo's Market</title>
	</head>
		
	<body>
	 <pre>
		<?php print_r($_POST);?>
	 </pre>
	</body>
</html>
