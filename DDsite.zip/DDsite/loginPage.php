
<!-- James Gonzalez loginPage.php -->

<?php
	include_once('header.php');
?>

<!-- Site Information -->
<tr class = "information">
	<td colspan="4">
		<h3 class="center">Login</h3>
		<form action="print.php" method="post" class="form">
			<p><label for="email">E-mail Address:</label><input type="email" id="email" name="email" label/></p>
			<p><label for="password">Password:</label><input type="password" id="password" name="password" label/></p>
			<p class="center">
				<button type="submit" name="login">Login</button>
				<button type="reset" name="reset">Reset Form</button>
			</p>
			<p class="center red small">(Fields in <span class="">red</span> are required)</p>
		</form>
	</td>
</tr>

<?php
	include_once('footer.php');
?>
