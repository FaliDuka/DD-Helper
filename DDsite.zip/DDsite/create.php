
<!-- James Gonzalez create.php -->

<?php
	include_once('header.php');
?>

<!-- Site Information -->
<tr class = "information">
	<td colspan="4">
		<h3 class="center">Create Account</h3>
		<form action="print.php" method="post" class="form">
			<p><label for="username">User Name:</label><input type="text" id="username" name="username" label/></p>
			<p><label for="email">E-mail Address:</label><input type="email" id="email" name="email" label/></p>
			<p><label for="email_conf">Confirm E-mail Address:</label><input type="email" id="email_conf" name="email_conf" label/></p>
			<p>Select a password (minimum of 5 characters):</p>
			<p><label for="password">Password:</label><input type="password" id="password" name="password" label/></p>
			<p><label for="password_conf">Confirm password:</label><input type="password" id="password_conf" name="password_conf" label/></p>
			<p><label for="phone">Phone:</label><input type="input" id="phone" name="phone" class="phone"/> <input type="input" id="phone2" name="phone2"  class="phone"/> <input type="input" id="phone3" name="phone3"  class="phone"/></p>
			<p class="center">
				<button type="submit" name="create">Create Account</button>
				<button type="reset" name="reset">Reset Form</button>
			</p>
			<p class="center red small">(Fields in <span class="">red</span> are required)</p>
		</form>
	</td>
</tr>

<?php
	include_once('footer.php');
?>
