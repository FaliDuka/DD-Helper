<!-- James Gonzalez index.php -->

<?php
	include_once('header.php');
?>

<!-- Site Information -->
<tr class = "information">
	<td colspan="4">
		<h3>Welcome to <span class = "underlined-text">D&D Helper+</span></h3>
	<p>
		This is a <b>Dungeons & Dragons</b> website to help players play the game in a more organized fashion allowing ease of management with the game, while not taking away the players-imagination.

	</p>
	<p>
		<i>
			Please note that this is not an actual working website! It is just a prototype designed for CSC354-10
		</i>
	</p>
	<p>
		The navigation bar at the top of the page allows a user to browse the webpage, create an account, Create character sheets, and view recent characters.  In order to build a "character sheet", the user must create and verify there account in order to properly login and start creating.

	</p>
	<p>
		<i>Enjoy your "Dungeons & Dragons" experience!</i>
	</p>
	<br>
	<center>
                                <h3>D&D Helper+ Creators!</h3>
                                <p>Nick Krott, James Gonzalez, Zachery Johnson, Thomas Ware</p>
	</center>
	</td>
</tr>



