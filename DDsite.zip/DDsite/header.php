<!-- James Gonzalez header.php -->
<!DOCTYPE html>

<html>
	
	<head>
		<meta charset="utf-8">
		<title>D&D Helper+</title>
		<link rel="stylesheet" href="style.css">
	</head>
		
	<body>

		<!-- Table -->
		<table>

		<!-- Heading -->
		<tr class = "heading">
			<td colspan="4">
			<h1 align="center"style= "color:Black;font-size:60px;"><b><em>D&D Helper+</b></em><img alt="D&D Logo" width= "50" height="60" style ="vertical-align:bottom" class="hCL kVc L4E MIw" importance="auto" loading="auto" src="https://cdn.shopify.com/s/files/1/0890/1750/files/full_colorno_txt_no_flames_9955d095-d56c-4bfe-905f-d54071c4d4da_600x.png"> </h1>
			</td>
		</tr>

		<!-- Site Links -->
		<tr class = "navbar">
			<td>
				<a href="index.php"style="color:black;"><b>Home</b></a>
			</td>
			<td>
				<a href="#"style="color:black;"><b>Character Sheet</b></a>
			</td>
			<td class = "dropdown">
					<a href = "#" class = "dropdown-button"style="color:black;"><b>My Characters</b></a>
					<ul class = "dropdown-menu">
						<li><a href="#">Show Character</a></li>
						<li><a href="#">Clear Character</a></li>
						<li><a href="#">My Characters</a></li>
					</ul>
			</td>
			<td class = "dropdown">
					<a href = "#" class = "dropdown-button"style="color:black;"><b>D&D Account</b></a>
					<ul class = "dropdown-menu">
						<li><a href="loginPage.php">Login</a></li>
						<li><a href="#">Logout</a></li>
						<li><a href="create.php">Create Account</a></li>
					</ul>
			</td>
		</tr>
