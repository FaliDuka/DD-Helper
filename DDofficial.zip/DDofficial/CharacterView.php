
 <?php
   session_start();

// We need to use sessions, so you should always start sessions using the below code.

$DATABASE_HOST = 'aa1r3vx5tyutlo3.ctns8zlbhhqu.us-east-2.rds.amazonaws.com';
$DATABASE_USER = 'admin';
$DATABASE_PASS = 'Kutztown!';
$DATABASE_NAME = 'ebdb';
// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Home Page</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
	<h1>DnD Helper+ Character View</h1>
    <a href="homepage.html"><i class="fas fa-user-circle"></i>Profile</a>
	<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
	</div>
	</nav>
	<div class="content">
    <h2> Characters</h2>
	<?php

  $characterColumns = array(
    'Chname' => 'Character Name',
    'lvlE' => 'Level',
    'Hit' => 'Hit',
    'Throws' => 'Throws',
    'Initiative' => 'Initiative',
    'Speed' => 'Speed',
    'Inspir' => 'Inspiration',
    'PB' => 'Proficiency bonus',
    'PW' => 'Passive wisdom',
    'FT' => 'Features and Traits',
    'Prof' => 'Proficiency',
    'WEAP' => 'Weapons',
    'Arm' => 'Armor',
    'Trinkets' => 'Trinkets',
    'Acrobatics' => 'Acrobatics',
    'animalHandling' => 'Animal Handling',
    'Arcana' => 'Arcana',
    'Athletics' => 'Athletics',
    'Deception' => 'Deception',
    'History' => 'History',
    'Insight' => 'Insight',
    'Intimidation' => 'Intimidation',
    'Investigation' => 'Investigation',
    'Medicine' => 'Medicine',
    'Nature' => 'Nature',
    'Perception' => 'Perception',
    'Persuation' => 'Persuation',
    'Religion' => 'Religion',
    'Sleightofhand' => 'Sleightofhand',
    'stealth' => 'stealth',
    'Survival' => 'Survival',
    'Strength' => 'Strength',
    'Dexterity' => 'Dexterity',
    'Constitution' => 'Constitution',
    'Intelligence' => 'Intelligence',
    'Wisdom' => 'Wisdom',
    'Charisma' => 'Charisma'
  );



//$stmt = $con->prepare("SELECT Chname,lvlE,Hit,Throws,Init,Speed,Inspir,PB,PW,FT,Prof,WEAP,Arm,Trinkets,Acrobatics,animalHandling,Arcana,Athletics,Deception,History,Insight,Intimidation,Investigation,Medicine,Nature,Perception,Persuation,Religion,Sleightofhand,stealth,Survival,Strength,Dexterity,Constitution,Intelligence,Wisdom,Charisma FROM Characters WHERE id = '$_SESSION[\'id\']';");
$stmtColumns = implode(',', array_keys($characterColumns));

$stmt = $con->query("SELECT $stmtColumns FROM Characters WHERE AccountID = " . $_SESSION['id']);
while ($result = $stmt -> fetch_assoc()){

	foreach($characterColumns as $columnName => $columnDisplayValue) {

    echo "<b>" . $columnDisplayValue . ":</b> " . $result[$columnName] . "<br>";

  }

}

?>

<p><a href="homepage.php">Back to home</a></p>



		</div>

</body>
</html>