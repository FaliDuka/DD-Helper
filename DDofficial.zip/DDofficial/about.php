			
<!-- Site Information -->
<tr class = "information">
	<td colspan="4">
		<h3>Welcome to <span class = "underlined-text">Jimbo's Market!</span></h3>
	<p>
		This is an <b>example</b> website for an on-line store that sells an electric 
		mix of products. The site includes a catalog of products and a facility for 
		creating and maintaining customer accounts, complete with a shipping cart 
		for "ordering" items.
	</p>
	<p>
		<i>
			Please note that this is not an actual on-line store! It is just an example -
			designed for a web programming course.
		</i>
	</p>
	<p>
		The navigation bar at the top of the page allows a visitor to browse items in
		the store by category, or to search for a product by name. In order to
	"	place an order", however, a customer account is required.
	</p>
	<p>
		<i>Enjoy your "shopping" experience!</i>
	</p>
	</td>
</tr>
