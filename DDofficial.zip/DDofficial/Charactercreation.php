  <?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
$DATABASE_HOST = 'aa1r3vx5tyutlo3.ctns8zlbhhqu.us-east-2.rds.amazonaws.com';
$DATABASE_USER = 'admin';
$DATABASE_PASS = 'Kutztown!';
$DATABASE_NAME = 'ebdb';
// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Home Page</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
			
	<h1>DnD Helper+ Character Creation</h1>
    <a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
	<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
	</div>
	</nav>
	<div class="content">
    <h2> Character Created </h2>
    <p><?=$_SESSION['name']?>'s Character has been created</p>
<?php
 $un = $_POST['Uname'];
 $nn= $_POST['Chname'];
 $st=$_POST['stats'];
 $sk=$_POST['skills'];
 $cd=$_POST['CharData'];
 $lvl=$_POST['lvlE'];
 $hit=$_POST['Hit'];
 $thr=$_POST['Throws'];
 $init=$_POST['Init'];
 $sp=$_POST['Speed'];
 $insp=$_POST['Inspir'];
 $pb=$_POST['PB'];
 $pw=$_POST['PW'];
 $ft=$_POST['FT'];
 $prof=$_POST['Prof'];
 $weap=$_POST['Weap'];
 $arm=$_POST['Arm'];
 $tr=$_POST['Trinkets'];
 $Ac=$_POST['Acrobatics'];
 $AH=$_POST['animalHandling'];
 $Arc=$_POST['Arcana'];
 $Alth=$_POST['Athletics'];
 $Dec=$_POST['Deception'];
 $His=$_POST['History'];
 $ins=$_POST['Insight'];
 $Intim=$_POST['Intimidation'];
 $inves=$_POST['Investigation'];
 $Med=$_POST['Medicine'];
 $Nat=$_POST['Nature'];
 $perc=$_POST['Perception'];
 $pers=$_POST['Persuation'];
 $rel=$_POST['Religion'];
 $SlH=$_POST['Sleightofhand'];
 $Ste=$_POST['stealth'];
 $surv=$_POST['Survival'];
 $Str=$_POST['Strength'];
 $Dext=$_POST['Dexterity'];
 $Cons=$_POST['Constitution'];
 $INtell=$_POST['Intelligence'];
 $wis=$_POST['Wisdom'];
 $Cha=$_POST['Charisma'];
if ($stmt = $con->prepare('INSERT INTO Characters(Uname,Chname,stats,skills,Chardata,lvlE,Hit,Throws,Init,Speed,Inspir,PB,PW,FT,Prof,WEAP,Arm,Trinkets,Acrobatics,
animalHandling,Arcana,Athletics,Deception,History,Insight,Intimidation,Investigation,
Medicine,Nature,Perception,Persuation,Religion,Sleightofhand,stealth,Survival,Strength,
Dexterity,Constitution,Intelligence,Wisdom,Charisma)
value($un,$nn,$st,$sk,$cd,$lvl,$hit,$thr,$init,$sp,$insp,$pb,$pw,$ft,$prof,$weap,$arm,$tr,$Ac,$AH,$Arc,$Alth,$Dec,$His,$ins,$Intim,$inves,
$Med,$Nat,$perc,$pers,$rel,$SlH,$Ste,$surv,$Str,$Dext,$Cons,$INtell,$wis,$Cha)')){
$stmt->execute();
$stmt->store_result();}
 else {
	// Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
	echo 'Could not prepare statement!';
}
?>
<p><a href="home.php">Back to home</a></p>
<p><a href="Charactercreation.html">Make another hero</a></p>

		
		</div>
	</body>
</html>
